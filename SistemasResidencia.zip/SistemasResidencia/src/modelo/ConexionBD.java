/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

public class ConexionBD {
    private static final String URL = "jdbc:mysql://localhost:3306/sistemaresidencia"; // Cambia si usas otro SGBD o puerto
    private static final String USER = "root"; // Tu usuario de la base de datos
    private static final String PASSWORD = "admin"; // Tu contraseña de la base de datos
    private Connection conexion = null;

    public Connection conectar() {
        try {
            // Cargar el driver JDBC (asegúrate de que sea el correcto para tu BD)
            Class.forName("com.mysql.cj.jdbc.Driver"); // Ejemplo para MySQL. Cambia si usas otro SGBD.
            conexion = DriverManager.getConnection(URL, USER, PASSWORD);
            // System.out.println("Conexión exitosa a la base de datos."); // Para depuración
        } catch (ClassNotFoundException ex) {
            JOptionPane.showMessageDialog(null, "Error al cargar el driver de la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al conectar con la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        }
        return conexion;
    }

    public void desconectar() {
        try {
            if (conexion != null && !conexion.isClosed()) {
                conexion.close();
                // System.out.println("Conexión cerrada."); // Para depuración
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(null, "Error al cerrar la conexión con la base de datos: " + ex.getMessage());
            ex.printStackTrace();
        }
    }
}
  