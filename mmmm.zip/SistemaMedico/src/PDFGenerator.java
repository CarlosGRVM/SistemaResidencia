/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alane
 */
public class PDFGenerator {
    public static void generateBitacoraPDF(BitacoraPanel panel) {
        // TODO: implementar con iText o similar
    }
    public static void generateRecetaPDF(RecetaPanel panel) {
        // TODO
    }
    public static void generateIncapacidadPDF(IncapacidadPanel panel) {
        // TODO
    }
}