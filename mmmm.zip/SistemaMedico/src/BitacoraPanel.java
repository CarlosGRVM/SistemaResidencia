/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alane
 */

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BitacoraPanel extends JPanel {
    private JTextField txtNombrePaciente, txtNumControl, txtEspecialidad, txtEdad, txtFecha;
    private JTextArea txtDiagnostico, txtTratamiento;
    private JRadioButton rbSiIncapacidad, rbNoIncapacidad;
    private JTextField txtNombreMedico;
    private DefaultTableModel model;

    public BitacoraPanel() {
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // Formulario superior
        JPanel form = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5,5,5,5);
        gbc.anchor = GridBagConstraints.WEST;

        // Fecha
        gbc.gridx=0; gbc.gridy=0;
        form.add(new JLabel("FECHA:"), gbc);
        gbc.gridx=1;
        txtFecha = new JTextField(
            new SimpleDateFormat("dd/MM/yyyy HH:mm").format(new Date()),
            20
        );
        txtFecha.setEditable(false);
        form.add(txtFecha,gbc);

        // Nombre
        gbc.gridx=0; gbc.gridy=1;
        form.add(new JLabel("NOMBRE:"), gbc);
        gbc.gridx=1;
        txtNombrePaciente = new JTextField(30);
        form.add(txtNombrePaciente,gbc);

        // Edad
        gbc.gridx=0; gbc.gridy=2;
        form.add(new JLabel("EDAD:"), gbc);
        gbc.gridx=1;
        txtEdad = new JTextField(5);
        form.add(txtEdad,gbc);

        // Núm. de Control
        gbc.gridx=0; gbc.gridy=3;
        form.add(new JLabel("NÚM. DE CONTROL:"), gbc);
        gbc.gridx=1;
        txtNumControl = new JTextField(10);
        form.add(txtNumControl,gbc);

        // Especialidad
        gbc.gridx=0; gbc.gridy=4;
        form.add(new JLabel("ESPECIALIDAD:"), gbc);
        gbc.gridx=1;
        txtEspecialidad = new JTextField(15);
        form.add(txtEspecialidad,gbc);

        // Diagnóstico
        gbc.gridx=0; gbc.gridy=5;
        form.add(new JLabel("DIAGNÓSTICO:"), gbc);
        gbc.gridx=1;
        txtDiagnostico = new JTextArea(3,30);
        form.add(new JScrollPane(txtDiagnostico),gbc);

        // Tratamiento
        gbc.gridx=0; gbc.gridy=6;
        form.add(new JLabel("TRATAMIENTO:"), gbc);
        gbc.gridx=1;
        txtTratamiento = new JTextArea(3,30);
        form.add(new JScrollPane(txtTratamiento),gbc);

        // Incapacidad
        gbc.gridx=0; gbc.gridy=7;
        form.add(new JLabel("INCAPACIDAD:"), gbc);
        gbc.gridx=1;
        rbSiIncapacidad = new JRadioButton("Sí");
        rbNoIncapacidad = new JRadioButton("No", true);
        ButtonGroup bg = new ButtonGroup();
        bg.add(rbSiIncapacidad); bg.add(rbNoIncapacidad);
        JPanel radioP = new JPanel();
        radioP.add(rbSiIncapacidad); radioP.add(rbNoIncapacidad);
        form.add(radioP,gbc);

        // Médico
        gbc.gridx=0; gbc.gridy=8;
        form.add(new JLabel("MÉDICO/FIRMA:"), gbc);
        gbc.gridx=1;
        txtNombreMedico = new JTextField(30);
        form.add(txtNombreMedico,gbc);

        add(form, BorderLayout.NORTH);

        // Tabla de registros
        String[] cols = {"NÚM. CONTROL","ESPECIALIDAD","DIAGNÓSTICO & TRATAMIENTO"};
        model = new DefaultTableModel(cols,0);
        JTable table = new JTable(model);
        table.setPreferredScrollableViewportSize(new Dimension(700,200));
        add(new JScrollPane(table), BorderLayout.CENTER);

        // Botones
        JPanel btnP = new JPanel();
        JButton btnAdd = new JButton("Agregar");
        btnAdd.addActionListener(e -> onAgregar());
        JButton btnPDF = new JButton("Guardar PDF");
        btnPDF.addActionListener(e -> PDFGenerator.generateBitacoraPDF(this));
        btnP.add(btnAdd); btnP.add(btnPDF);
        add(btnP, BorderLayout.SOUTH);
    }

    private void onAgregar() {
        model.addRow(new Object[]{
            txtNumControl.getText(),
            txtEspecialidad.getText(),
            txtDiagnostico.getText()+"\n"+txtTratamiento.getText()
        });
        // Limpiar
        txtNumControl.setText(""); txtEspecialidad.setText("");
        txtDiagnostico.setText(""); txtTratamiento.setText("");
    }

    // Getters para usar en otros paneles
    public String getNombre()     { return txtNombrePaciente.getText(); }
    public String getEdad()       { return txtEdad.getText(); }
    public String getNumControl(){ return txtNumControl.getText(); }
    public String getDiagnostico(){ return txtDiagnostico.getText(); }
    public String getTratamiento(){ return txtTratamiento.getText(); }
}
