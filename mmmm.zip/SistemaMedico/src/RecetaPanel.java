/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alane
 */

import javax.swing.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class RecetaPanel extends JPanel {
    private BitacoraPanel origen;
    private JTextField txtNombreReceta, txtFechaReceta, txtEdadReceta, txtControlReceta;

    public RecetaPanel(BitacoraPanel bit) {
        this.origen = bit;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createEmptyBorder(10,10,10,10));

        // Encabezado mínimo
        add(new JLabel("RECETA MÉDICA", JLabel.CENTER), BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(4,2,5,5));
        form.add(new JLabel("Nombre:"));
        txtNombreReceta = new JTextField(); txtNombreReceta.setEditable(false);
        form.add(txtNombreReceta);

        form.add(new JLabel("Fecha:"));
        txtFechaReceta = new JTextField(
            new SimpleDateFormat("dd/MM/yyyy").format(new Date())
        ); txtFechaReceta.setEditable(false);
        form.add(txtFechaReceta);

        form.add(new JLabel("Edad:"));
        txtEdadReceta = new JTextField(); txtEdadReceta.setEditable(false);
        form.add(txtEdadReceta);

        form.add(new JLabel("No. Control:"));
        txtControlReceta = new JTextField(); txtControlReceta.setEditable(false);
        form.add(txtControlReceta);

        add(form, BorderLayout.CENTER);

        JButton btnPDF = new JButton("Guardar Receta PDF");
        btnPDF.addActionListener(e -> PDFGenerator.generateRecetaPDF(this));
        add(btnPDF, BorderLayout.SOUTH);

        // Carga inicial de datos
        cargarDatos();
    }

    private void cargarDatos() {
        txtNombreReceta.setText(origen.getNombre());
        txtEdadReceta.setText(origen.getEdad());
        txtControlReceta.setText(origen.getNumControl());
    }
}