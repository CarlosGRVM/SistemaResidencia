/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alane
 */


import javax.swing.*;
import java.awt.*;

public class IncapacidadPanel extends JPanel {
    private BitacoraPanel origen;
    private JTextField txtDias;

    public IncapacidadPanel(BitacoraPanel bit) {
        this.origen = bit;
        setLayout(new BorderLayout(10,10));
        setBorder(BorderFactory.createTitledBorder("FICHA MÉDICA DE INCAPACIDAD"));

        JPanel form = new JPanel(new GridLayout(2,2,5,5));
        form.add(new JLabel("Nombre:"));
        JTextField txtNom = new JTextField(); txtNom.setEditable(false);
        form.add(txtNom);

        form.add(new JLabel("Días de incapacidad:"));
        txtDias = new JTextField();
        form.add(txtDias);

        add(form, BorderLayout.CENTER);

        JButton btnPDF = new JButton("Guardar Incapacidad PDF");
        btnPDF.addActionListener(e -> PDFGenerator.generateIncapacidadPDF(this));
        add(btnPDF, BorderLayout.SOUTH);

        txtNom.setText(origen.getNombre());
    }
}