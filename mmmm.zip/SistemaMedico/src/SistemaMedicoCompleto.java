/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author alane
 */


import javax.swing.*;
import java.awt.*;

public class SistemaMedicoCompleto extends JFrame {
    private JTabbedPane tabbedPane;

    public SistemaMedicoCompleto() {
        super("Sistema Médico - Instituto Tecnológico de Oaxaca");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 700);
        setLocationRelativeTo(null);

        tabbedPane = new JTabbedPane();

        // Crear instancias de cada panel
        BitacoraPanel bitacoraPanel = new BitacoraPanel();
        RecetaPanel recetaPanel = new RecetaPanel(bitacoraPanel);
        IncapacidadPanel incapacidadPanel = new IncapacidadPanel(bitacoraPanel);

        tabbedPane.addTab("Bitácora Médica", bitacoraPanel);
        tabbedPane.addTab("Receta Médica", recetaPanel);
        tabbedPane.addTab("Incapacidad", incapacidadPanel);

        add(tabbedPane);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            new SistemaMedicoCompleto().setVisible(true);
        });
    }
}