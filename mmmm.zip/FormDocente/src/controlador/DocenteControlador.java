/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package controlador;


import modelo.Docente;
import modelo.DocenteDAO;
import form.docente; 
import javax.swing.table.DefaultTableModel;
import java.sql.SQLException;
import java.util.List;
import javax.swing.JOptionPane;
import java.util.logging.Level;
import java.util.logging.Logger;

public class DocenteControlador {

    private docente view; 
    private DocenteDAO model; 
    private DefaultTableModel tableModel; 
    
    public DocenteControlador(docente view) {
        this.view = view;
        this.model = new DocenteDAO(); 
        String[] columnNames = {"ID", "No. Empleado", "Nombre", "Apellido Paterno", "Apellido Materno", "Correo"};
        this.tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; 
            }
        };
    }

    public void guardarDocente() {
        String noEmpleado = view.getTxtEmpleado().getText();
        String nombre = view.getTxtNombre().getText();
        String apellidoP = view.getTxtApellidoP().getText();
        String apellidoM = view.getTxtApellidoM().getText();
        String correo = view.getTxtCorreo().getText();

        Docente nuevoDocente = new Docente(noEmpleado, nombre, apellidoP, apellidoM, correo);

        model.guardarDocente(nuevoDocente);
        limpiarCamposFormulario();
        deshabilitarCamposFormulario();
    }

    public void habilitarCamposFormulario() {
        view.getTxtEmpleado().setEnabled(true);
        view.getTxtNombre().setEnabled(true);
        view.getTxtApellidoP().setEnabled(true);
        view.getTxtApellidoM().setEnabled(true);
        view.getTxtCorreo().setEnabled(true);
        view.getBGUARDAR().setEnabled(true);
    }

    public void deshabilitarCamposFormulario() {
        view.getTxtEmpleado().setEnabled(false);
        view.getTxtNombre().setEnabled(false);
        view.getTxtApellidoP().setEnabled(false);
        view.getTxtApellidoM().setEnabled(false);
        view.getTxtCorreo().setEnabled(false);
        view.getBGUARDAR().setEnabled(false);
    }

    public void limpiarCamposFormulario() {
        view.getTxtEmpleado().setText("");
        view.getTxtNombre().setText("");
        view.getTxtApellidoP().setText("");
        view.getTxtApellidoM().setText("");
        view.getTxtCorreo().setText("");
    }

    public void regresarVentana() {
        view.dispose();
    }
} 
