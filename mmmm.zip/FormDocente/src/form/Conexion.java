/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
// src/form/Conexion.java (Asegúrate que se vea así o similar)
package form;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conexion {
    private String DB_URL = "jdbc:mysql://localhost:3306/sistema_docentes";
        private String DB_USER = "root";
        private String DB_PASSWORD = "1234";

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
    }
}