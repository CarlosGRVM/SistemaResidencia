/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package modelo;

/**
 *
 * @author ubuntu
 */
public class PruebaConexion {

    public static void main(String[] args) {
        ModeloCandidatoBD dao = new ModeloCandidatoBD();

        ModeloCandidato c = new ModeloCandidato(
                "12345678",
                "Pedro",
                "López",
                "García",
                "9511234567",
                "pedro@gmail.com"
        );

        boolean resultado = dao.insertar(c);
        System.out.println("Resultado insert: " + resultado);
    }
}
