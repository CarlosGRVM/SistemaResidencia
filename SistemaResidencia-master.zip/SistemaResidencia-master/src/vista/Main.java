/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package vista;

/**
 *
 * @author ubuntu
 */
import controlador.CandidatoControlador;
import vista.RegistroCandidato;

public class Main {
    public static void main(String[] args) {
        RegistroCandidato vista = new RegistroCandidato();
        CandidatoControlador controlador = new CandidatoControlador(vista);
        
        
    }
}
