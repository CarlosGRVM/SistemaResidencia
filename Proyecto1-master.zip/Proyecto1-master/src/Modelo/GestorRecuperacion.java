package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


public class GestorRecuperacion {
    private static String correoActual;

    // Inicia el proceso: guarda el correo, envía el código y lo guarda temporalmente
    public static void iniciar(String correo) {
        correoActual = correo;

        if (!correoExiste(correo)) {
            System.err.println("El correo no está registrado.");
            return;
        }

        String codigo = CodigoVerificacion.generarCodigo(); // Genera el código
        CodigoVerificacion.guardar(codigo);                 // Lo guarda temporalmente

        boolean enviado = Correo.enviarCorreo(correo, codigo); // Enviar usando el nuevo método

        if (!enviado) {
            System.err.println("Error: no se pudo enviar el correo.");
        }
    }

    // Verifica si el código ingresado es correcto
    public static boolean verificar(String codigo) {
        return CodigoVerificacion.verificar(codigo);
    }

    // Actualiza la contraseña en la BD para el correoActual
    public static boolean actualizar(String nueva) {
        String query = "UPDATE usuario SET Contrasena = ? WHERE Correo = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, nueva);
            ps.setString(2, correoActual);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            System.out.println("Error al actualizar la contraseña: " + e.getMessage());
        }

        return false;
    }

    // Verifica si el correo existe en la BD
    public static boolean correoExiste(String correo) {
        String query = "SELECT COUNT(*) FROM usuario WHERE Correo = ?";

        try (Connection conn = ConexionBD.conectar();
             PreparedStatement ps = conn.prepareStatement(query)) {

            ps.setString(1, correo);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return rs.getInt(1) > 0;
                }
            }

        } catch (SQLException e) {
            System.out.println("Error al verificar correo: " + e.getMessage());
        }

        return false;
    }

    public static String getCorreoActual() {
        return correoActual;
    }
}
