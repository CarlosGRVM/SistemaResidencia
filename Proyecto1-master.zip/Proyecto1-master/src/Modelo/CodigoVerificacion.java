package modelo;

import java.util.Random;

public class CodigoVerificacion {
    private static String codigoGuardado;
    private static String correoAsociado;

    // Genera un código de 4 dígitos aleatorio
    public static String generarCodigo() {
        Random r = new Random();
        int numero = 1000 + r.nextInt(9000); // Código entre 1000 y 9999
        return String.valueOf(numero);
    }

    // Guarda el código generado
    public static void guardar(String codigo) {
        codigoGuardado = codigo;
    }

    // Verifica si el código ingresado es correcto
    public static boolean verificar(String codigoIngresado) {
        return codigoGuardado != null && codigoGuardado.equals(codigoIngresado);
    }

    public static void setCorreoAsociado(String correo) {
        correoAsociado = correo;
    }

    public static String getCorreoAsociado() {
        return correoAsociado;
    }

    public static String getCodigoGuardado() {
        return codigoGuardado;
    }
}
