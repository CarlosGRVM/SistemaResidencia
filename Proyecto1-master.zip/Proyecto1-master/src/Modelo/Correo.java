package modelo;

import jakarta.mail.Authenticator;
import jakarta.mail.Message;
import jakarta.mail.MessagingException;
import jakarta.mail.PasswordAuthentication;
import jakarta.mail.Session;
import jakarta.mail.Transport;
import jakarta.mail.internet.InternetAddress;
import jakarta.mail.internet.MimeMessage;
import java.util.Properties;
import java.util.Random;

public class Correo {

    public static boolean enviarCorreo(String destino, String codigo) {
        final String remitente = "tucorreo@gmail.com"; // tu correo
        final String claveApp = "tu_contraseña_de_aplicación"; // contraseña de aplicación

        Properties props = new Properties();
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.port", "587");

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(remitente, claveApp);
            }
        });

        try {
            Message mensaje = new MimeMessage(session);
            mensaje.setFrom(new InternetAddress(remitente));
            mensaje.setRecipients(Message.RecipientType.TO, InternetAddress.parse(destino));
            mensaje.setSubject("Código de Verificación");
            mensaje.setText("Tu código de verificación es: " + codigo);

            Transport.send(mensaje);
            return true;

        } catch (MessagingException e) {
            System.out.println("Error al enviar correo: " + e.getMessage());
            return false;
        }
    }

    public static String generarCodigo() {
        Random r = new Random();
        int numero = 1000 + r.nextInt(9000); // Código de 4 dígitos
        return String.valueOf(numero);
    }
}
