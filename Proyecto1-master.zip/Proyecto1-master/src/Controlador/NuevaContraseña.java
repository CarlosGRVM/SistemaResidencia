/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author jeshu
 */
import javax.swing.*;
import modelo.GestorRecuperacion;


public class NuevaContraseña extends JFrame {
    private JPasswordField txtNueva;
    private JButton btnAceptar;

    public NuevaContraseña() {
        setTitle("Nueva Contraseña");
        txtNueva = new JPasswordField(20);
        btnAceptar = new JButton("Aceptar");

        btnAceptar.addActionListener(e -> {
            String nueva = new String(txtNueva.getPassword()).trim();
            if (!nueva.isEmpty()) {
                GestorRecuperacion.actualizar(nueva);
                JOptionPane.showMessageDialog(this, "Contraseña cambiada correctamente.");
                new RecuperarContraseña().setVisible(true);
                dispose();
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Nueva contraseña:"));
        panel.add(txtNueva);
        panel.add(btnAceptar);
        add(panel);
        pack();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
}
