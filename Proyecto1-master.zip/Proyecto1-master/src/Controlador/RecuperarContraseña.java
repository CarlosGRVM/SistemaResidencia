/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import javax.swing.*;
import modelo.GestorRecuperacion;
import Vistas.Verificacion;

public class RecuperarContraseña extends JFrame {
    private JTextField txtCorreo;
    private JButton btnEnviar;

    public RecuperarContraseña() {
        setTitle("Recuperar Contraseña");
        txtCorreo = new JTextField(20);
        btnEnviar = new JButton("Enviar");

        btnEnviar.addActionListener(e -> {
            String correo = txtCorreo.getText().trim();
            if (!correo.isEmpty()) {
                GestorRecuperacion.iniciar(correo);
                new Verificacion().setVisible(true);
                dispose();
            }
        });

        JPanel panel = new JPanel();
        panel.add(new JLabel("Correo:"));
        panel.add(txtCorreo);
        panel.add(btnEnviar);
        add(panel);
        pack();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new RecuperarContraseña().setVisible(true));
    }
}
