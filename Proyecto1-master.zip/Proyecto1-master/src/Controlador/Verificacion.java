/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author jeshu
 */
import javax.swing.*;
import modelo.GestorRecuperacion;
import java.awt.*;

public class Verificacion extends JFrame {

    private JTextField txt1, txt2, txt3, txt4;
    private JButton btnEnter;

    public Verificacion() {
        setTitle("Verificación de Código");
        setLayout(new BorderLayout());

        // Panel principal
        JPanel panelCentral = new JPanel();
        panelCentral.setLayout(new FlowLayout());

        txt1 = crearCampo();
        txt2 = crearCampo();
        txt3 = crearCampo();
        txt4 = crearCampo();

        panelCentral.add(new JLabel("Código:"));
        panelCentral.add(txt1);
        panelCentral.add(txt2);
        panelCentral.add(txt3);
        panelCentral.add(txt4);

        btnEnter = new JButton("Verificar");

        // Acción del botón
        btnEnter.addActionListener(e -> {
            String codigo = txt1.getText() + txt2.getText() + txt3.getText() + txt4.getText();
            if (codigo.matches("\\d{4}")) {
                if (GestorRecuperacion.verificar(codigo)) {
                    new NuevaContraseña().setVisible(true);
                    dispose();
                } else {
                    JOptionPane.showMessageDialog(this, "Código incorrecto.");
                }
            } else {
                JOptionPane.showMessageDialog(this, "Ingresa un código válido de 4 dígitos.");
            }
        });

        add(panelCentral, BorderLayout.CENTER);
        add(btnEnter, BorderLayout.SOUTH);

        pack();
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private JTextField crearCampo() {
        JTextField campo = new JTextField(1);
        campo.setFont(new Font("SansSerif", Font.BOLD, 24));
        campo.setHorizontalAlignment(JTextField.CENTER);
        return campo;
    }
}
