/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/**
 *
 * @author jeshu
 */

import javax.swing.JOptionPane;
import modelo.*;

public class ControladorRecuperacion {

    public static void manejarEnvioCodigo(String correo) {
        if (!GestorRecuperacion.correoExiste(correo)) {
            JOptionPane.showMessageDialog(null, "Correo no registrado.");
            return;
        }

        String codigo = CodigoVerificacion.generarCodigo();
        CodigoVerificacion.setCorreoAsociado(correo);

        boolean enviado = Correo.enviarCorreo(correo, codigo);
        if (enviado) {
            JOptionPane.showMessageDialog(null, "Código enviado al correo.");
            new Verificacion().setVisible(true); // Abre la siguiente interfaz
        } else {
            JOptionPane.showMessageDialog(null, "No se pudo enviar el correo.");
        }
    }
}
